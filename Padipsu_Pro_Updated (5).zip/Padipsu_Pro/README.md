# Padipsu Pro — mobile-first design + Flutter starter

This bundle includes:
- `web/index.html`: a self-contained interactive design prototype. Open it in a mobile browser to preview the screens and interactions.
- `lib/main.dart`: Flutter source for an Android app starter.
- `pubspec.yaml`: Flutter project manifest.

## Prototype features
- Home, Learn, Quiz, Progress and Settings navigation
- Tamil Nadu State Board / CBSE selection
- Class 10, 11 and 12 selection
- Subject cards and library search
- Sample quiz with answers and explanations
- Session-level progress display
- Responsive layout for phone and larger screens

## Important: not production-complete yet
This is a frontend prototype/starter, not a signed APK and not a published Play Store app. Actual board-specific content, PDF hosting, secure accounts, synced progress, AI tutor, admin upload tools, notification service, privacy policy, rights checks, testing, signing and release setup still need to be implemented.

## Mobile-only next steps
1. Download and extract the ZIP on your Android phone using a file manager.
2. Open `web/index.html` in a browser to test the design prototype.
3. For the Flutter source, use a cloud development environment that supports Flutter and Android builds, or a computer with Flutter/Android Studio.
4. Run `flutter pub get`, then `flutter run` to test.
5. Build with `flutter build apk --release` after testing and configuring the Android project.
6. Keep any Firebase credentials and AI API keys out of public client code. Use server-side functions for secret keys.

The website prototype is self-contained and does not call external services. Buttons for real content/backend features show demo messages rather than pretending a service is connected.

## Login choice (A): account screen added
`lib/auth_screen.dart` contains a registration/sign-in UI with name, email, password validation, password visibility, and privacy-notice checkbox. It is intentionally a UI-only demo and does not store or transmit credentials.

To integrate it into `main.dart`, import `auth_screen.dart` and make the root widget show `PadipsuAuthScreen` until a real auth provider confirms a signed-in session. For production, connect Firebase Authentication (email/password or other supported provider), configure secure account recovery, and never store plaintext passwords or ship API secrets in the app. Add and publish a real privacy policy before collecting student information.

## Updated membership + exam preview
- Home screen now shows NEET and JEE preparation entry points.
- Membership preview: 2 days limited free access, then ₹10/month.
- Practice screen includes NEET and JEE sample entry points.
- Payment, trial enforcement, real OTP login, video hosting and question-bank backend are NOT connected. The preview does not collect money or activate subscriptions.
