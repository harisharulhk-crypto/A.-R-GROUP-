import 'package:flutter/material.dart';

const padipsuBrand = Color(0xFF5B5FEF);
const padipsuInk = Color(0xFF15213B);
const padipsuBg = Color(0xFFF5F7FC);

class PadipsuAuthScreen extends StatefulWidget {
  final void Function(String name, String email) onSignedIn;
  const PadipsuAuthScreen({super.key, required this.onSignedIn});

  @override
  State<PadipsuAuthScreen> createState() => _PadipsuAuthScreenState();
}

class _PadipsuAuthScreenState extends State<PadipsuAuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _createAccount = true;
  bool _hidePassword = true;
  bool _acceptedPrivacy = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  String? _validateEmail(String? value) {
    final email = (value ?? '').trim();
    if (email.isEmpty || !email.contains('@') || !email.contains('.')) {
      return 'Enter a valid email address';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if ((value ?? '').length < 8) return 'Use at least 8 characters';
    return null;
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    if (_createAccount && !_acceptedPrivacy) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please accept the privacy notice to continue.')),
      );
      return;
    }
    // UI-only demo: no credentials are transmitted or stored.
    widget.onSignedIn(
      _createAccount && _name.text.trim().isNotEmpty
          ? _name.text.trim()
          : _email.text.trim().split('@').first,
      _email.text.trim(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: padipsuBg,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Container(
                      width: 64, height: 64,
                      decoration: BoxDecoration(
                        color: padipsuBrand,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Icon(Icons.auto_stories_rounded, color: Colors.white, size: 34),
                    ),
                  ),
                  const SizedBox(height: 15),
                  const Text('Padipsu', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: padipsuInk)),
                  const SizedBox(height: 5),
                  const Text('LEARN • PRACTISE • GROW', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 10, letterSpacing: 1.8, color: Colors.black54, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 28),
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: const Color(0xFFE8EAF4)),
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Text(_createAccount ? 'Create your account' : 'Welcome back',
                          style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: padipsuInk)),
                        const SizedBox(height: 6),
                        Text(_createAccount ? 'Start your learning journey today.' : 'Sign in to continue learning.',
                          style: const TextStyle(color: Colors.black54)),
                        const SizedBox(height: 22),
                        if (_createAccount) ...[
                          const Text('Full name', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                          const SizedBox(height: 7),
                          TextFormField(
                            controller: _name,
                            textCapitalization: TextCapitalization.words,
                            validator: (v) => (v ?? '').trim().length < 2 ? 'Enter your name' : null,
                            decoration: _decoration('Your name', Icons.person_outline_rounded),
                          ),
                          const SizedBox(height: 15),
                        ],
                        const Text('Email address', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                        const SizedBox(height: 7),
                        TextFormField(
                          controller: _email,
                          keyboardType: TextInputType.emailAddress,
                          validator: _validateEmail,
                          decoration: _decoration('you@example.com', Icons.mail_outline_rounded),
                        ),
                        const SizedBox(height: 15),
                        const Text('Password', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                        const SizedBox(height: 7),
                        TextFormField(
                          controller: _password,
                          obscureText: _hidePassword,
                          validator: _validatePassword,
                          decoration: _decoration('At least 8 characters', Icons.lock_outline_rounded).copyWith(
                            suffixIcon: IconButton(
                              onPressed: () => setState(() => _hidePassword = !_hidePassword),
                              icon: Icon(_hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                            ),
                          ),
                        ),
                        if (_createAccount) ...[
                          const SizedBox(height: 12),
                          CheckboxListTile(
                            contentPadding: EdgeInsets.zero,
                            controlAffinity: ListTileControlAffinity.leading,
                            value: _acceptedPrivacy,
                            onChanged: (v) => setState(() => _acceptedPrivacy = v ?? false),
                            title: const Text('I agree to the privacy notice.', style: TextStyle(fontSize: 12)),
                          ),
                        ],
                        const SizedBox(height: 10),
                        SizedBox(
                          height: 49,
                          child: FilledButton(
                            onPressed: _submit,
                            style: FilledButton.styleFrom(backgroundColor: padipsuBrand),
                            child: Text(_createAccount ? 'Create account' : 'Sign in',
                              style: const TextStyle(fontWeight: FontWeight.w800)),
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextButton(
                          onPressed: () => setState(() {
                            _createAccount = !_createAccount;
                            _formKey.currentState?.reset();
                          }),
                          child: Text(_createAccount ? 'Already have an account? Sign in' : 'New to Padipsu? Create account'),
                        ),
                        const SizedBox(height: 5),
                        const Text(
                          'Prototype only: this screen does not create a real account. Connect Firebase Authentication or another secure auth provider before using real passwords.',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 10, color: Colors.black54, height: 1.4),
                        ),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _decoration(String hint, IconData icon) => InputDecoration(
    hintText: hint,
    prefixIcon: Icon(icon),
    filled: true,
    fillColor: const Color(0xFFF8F9FD),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFE4E7F1))),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFE4E7F1))),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: padipsuBrand, width: 1.5)),
  );
}
