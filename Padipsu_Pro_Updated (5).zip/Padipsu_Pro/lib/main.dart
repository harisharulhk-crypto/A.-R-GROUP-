import 'package:flutter/material.dart';

void main() => runApp(const PadipsuApp());

const brand = Color(0xFF5B5FEF);
const ink = Color(0xFF15213B);
const bg = Color(0xFFF5F7FC);

class PadipsuApp extends StatelessWidget {
  const PadipsuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Padipsu',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: brand), scaffoldBackgroundColor: bg),
    home: const PadipsuHome(),
  );
}

class PadipsuHome extends StatefulWidget {
  const PadipsuHome({super.key});
  @override
  State<PadipsuHome> createState() => _PadipsuHomeState();
}

class _PadipsuHomeState extends State<PadipsuHome> {
  int tab = 0;
  String board = 'Tamil Nadu State Board';
  int grade = 12;
  final subjects = const [
    ('Physics', Icons.bolt, Color(0xFFE8EEFF), Color(0xFF465FE8)),
    ('Chemistry', Icons.science, Color(0xFFFFEBDD), Color(0xFFE47C38)),
    ('Mathematics', Icons.functions, Color(0xFFE0F8F1), Color(0xFF159C7E)),
    ('Biology', Icons.spa, Color(0xFFF5E7FF), Color(0xFF9A55CE)),
    ('English', Icons.menu_book, Color(0xFFFFE6EF), Color(0xFFD84E82)),
    ('Tamil', Icons.translate, Color(0xFFE1F4FF), Color(0xFF268FC5)),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [_home(), _learn(), _quiz(), _progress()];
    return Scaffold(
      appBar: AppBar(title: const Row(children: [
        CircleAvatar(backgroundColor: brand, child: Icon(Icons.auto_stories, color: Colors.white)),
        SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Padipsu', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: ink)),
          Text('LEARN • PRACTISE • GROW', style: TextStyle(fontSize: 9, letterSpacing: 1, color: Colors.black54)),
        ]),
      ])),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.library_books_outlined), label: 'Learn'),
          NavigationDestination(icon: Icon(Icons.quiz_outlined), label: 'Quiz'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Progress'),
        ],
      ),
    );
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(18), children: [
    Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF555BE7), Color(0xFF8178FA)]), borderRadius: BorderRadius.circular(25)),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('YOUR NEXT CHAPTER STARTS HERE', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
        SizedBox(height: 12),
        Text('Learn smarter.\\nScore higher. ✨', style: TextStyle(color: Colors.white, fontSize: 29, height: 1.15, fontWeight: FontWeight.w900)),
        SizedBox(height: 10),
        Text('Notes, question papers and practice in one place.', style: TextStyle(color: Colors.white)),
      ]),
    ),
    const SizedBox(height: 22),
    Row(children: [
      Expanded(child: _selectCard('BOARD', board, Icons.school, () => _chooseBoard())),
      const SizedBox(width: 10),
      Expanded(child: _selectCard('CLASS', '$gradeᵗʰ Standard', Icons.class_, () => _chooseGrade())),
    ]),
    const SizedBox(height: 24),
    const Text('Pick a subject', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 12),
    GridView.builder(
      shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
      itemCount: subjects.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.55),
      itemBuilder: (context, i) {
        final s = subjects[i];
        return InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => _subjectDialog(s.$1),
          child: Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8EAF4))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            CircleAvatar(backgroundColor: s.$3, child: Icon(s.$2, color: s.$4)),
            Text(s.$1, style: const TextStyle(fontWeight: FontWeight.w800, color: ink)),
          ])),
        );
      },
    ),
    const SizedBox(height: 18),
    _action(Icons.bolt, 'Sample MCQ quiz', 'Try a short quiz with instant score', () => setState(() => tab = 2)),
    const SizedBox(height: 10),
    _action(Icons.picture_as_pdf, 'Question paper library', 'Connect verified PDFs and notes', () => setState(() => tab = 1)),
    const SizedBox(height: 18),
    const Text('Starter version · Verified study content and cloud services must be connected before release.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontSize: 11)),
  ]);

  Widget _learn() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Learning library', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 6),
    const Text('Tamil Nadu State Board + CBSE · Classes 10–12'),
    const SizedBox(height: 18),
    _selectCard('BOARD', board, Icons.school, _chooseBoard),
    const SizedBox(height: 10),
    _selectCard('CLASS', '$gradeᵗʰ Standard', Icons.class_, _chooseGrade),
    const SizedBox(height: 18),
    ...subjects.map((s) => Padding(padding: const EdgeInsets.only(bottom: 10), child: _action(s.$2, s.$1, 'Chapter notes • Practice • Question papers', () => _subjectDialog(s.$1)))),
    const SizedBox(height: 8),
    const Text('Add verified, board-specific PDF files and notes to make this library useful.', style: TextStyle(color: Colors.black54)),
  ]);

  Widget _quiz() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Practice zone', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 8),
    const Text('Try a five-question sample quiz.'),
    const SizedBox(height: 18),
    _action(Icons.quiz, 'Science warm-up', 'Five sample questions with instant score', _startQuiz),
  ]);

  Widget _progress() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Your progress', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 8),
    const Text('Your dashboard is ready to connect to saved quiz history.'),
    const SizedBox(height: 18),
    _action(Icons.insights, 'Study activity', 'Cloud-synced progress can be added with Firebase', () => _message('Progress syncing needs a secure backend.')),
  ]);

  Widget _selectCard(String label, String value, IconData icon, VoidCallback onTap) => InkWell(
    onTap: onTap,
    child: Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE8EAF4))), child: Row(children: [
      Icon(icon, color: brand), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 9, letterSpacing: 1, color: Colors.black45, fontWeight: FontWeight.w800)),
        Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: ink), overflow: TextOverflow.ellipsis),
      ])),
      const Icon(Icons.keyboard_arrow_down, size: 18),
    ])),
  );

  Widget _action(IconData icon, String title, String subtitle, VoidCallback onTap) => ListTile(
    onTap: onTap, tileColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFFE8EAF4))),
    leading: CircleAvatar(backgroundColor: const Color(0xFFE8EEFF), child: Icon(icon, color: brand)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: ink)),
    subtitle: Text(subtitle),
    trailing: const Icon(Icons.chevron_right),
  );

  void _chooseBoard() async {
    final result = await showModalBottomSheet<String>(context: context, builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      for (final b in ['Tamil Nadu State Board', 'CBSE']) ListTile(title: Text(b), onTap: () => Navigator.pop(ctx, b)),
    ])));
    if (result != null) setState(() => board = result);
  }

  void _chooseGrade() async {
    final result = await showModalBottomSheet<int>(context: context, builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      for (final g in [10, 11, 12]) ListTile(title: Text('Class $g'), onTap: () => Navigator.pop(ctx, g)),
    ])));
    if (result != null) setState(() => grade = result);
  }

  void _subjectDialog(String subject) => showModalBottomSheet<void>(
    context: context, showDragHandle: true,
    builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(subject, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      Text('$board • Class $grade'),
      const SizedBox(height: 14),
      const ListTile(leading: Icon(Icons.notes), title: Text('Chapter notes'), subtitle: Text('Content integration needed')),
      const ListTile(leading: Icon(Icons.picture_as_pdf), title: Text('Question papers'), subtitle: Text('Add verified PDF files')),
      ListTile(leading: const Icon(Icons.quiz), title: const Text('Practice MCQs'), onTap: () { Navigator.pop(ctx); setState(() => tab = 2); }),
    ])),
  );

  void _startQuiz() {
    const questions = [
      ('Which unit measures electric current?', ['Volt', 'Ampere', 'Ohm', 'Watt'], 1),
      ('What is the chemical formula for water?', ['CO₂', 'O₂', 'H₂O', 'NaCl'], 2),
      ('Which plant part usually absorbs water?', ['Flower', 'Leaf', 'Root', 'Fruit'], 2),
      ('What is 12 × 8?', ['86', '92', '96', '108'], 2),
      ('Which gas do plants absorb during photosynthesis?', ['Oxygen', 'Carbon dioxide', 'Hydrogen', 'Nitrogen'], 1),
    ];
    int index = 0, score = 0;
    void next() {
      if (index >= questions.length) {
        Navigator.pop(context);
        _message('Quiz complete! Score: $score / ${questions.length}');
        return;
      }
      final q = questions[index];
      showDialog<int>(context: context, barrierDismissible: false, builder: (ctx) {
        int? selected;
        return StatefulBuilder(builder: (ctx, setLocal) => AlertDialog(
          title: Text('Question ${index + 1} / ${questions.length}'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(q.$1),
            ...List.generate(q.$2.length, (i) => RadioListTile<int>(contentPadding: EdgeInsets.zero, value: i, groupValue: selected, title: Text(q.$2[i]), onChanged: (v) => setLocal(() => selected = v))),
          ]),
          actions: [FilledButton(onPressed: selected == null ? null : () { if (selected == q.$3) score++; Navigator.pop(ctx, selected); }, child: const Text('Submit'))],
        );
      }).then((_) { index++; if (mounted) next(); });
    }
    next();
  }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}
